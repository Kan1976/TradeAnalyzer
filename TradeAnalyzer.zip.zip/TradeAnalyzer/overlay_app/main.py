# overlay_app/main.py
# Overlay App for TradeAnalyzer — обновляет данные каждую секунду
# Использует candle_analyzer.predict_from_image(path)
from kivy.app import App
from kivy.clock import Clock
from kivy.uix.widget import Widget
import os, traceback

# Попробуем импортировать анализатор — fallback на machine_learning, если нужно
candle_analyzer = None
try:
    import candle_analyzer
except Exception:
    try:
        import machine_learning as candle_analyzer
    except Exception:
        candle_analyzer = None

# pyjnius android imports (работают только на Android в APK)
try:
    from jnius import autoclass, cast
    PythonActivity = autoclass('org.kivy.android.PythonActivity')
    Context = autoclass('android.content.Context')
    Intent = autoclass('android.content.Intent')
    Settings = autoclass('android.provider.Settings')
    Build = autoclass('android.os.Build')
    WindowManager = autoclass('android.view.WindowManager')
    LayoutParams = autoclass('android.view.WindowManager$LayoutParams')
    Gravity = autoclass('android.view.Gravity')
    TextView = autoclass('android.widget.TextView')
    Color = autoclass('android.graphics.Color')
    ANDROID_AVAILABLE = True
    activity = PythonActivity.mActivity
except Exception:
    ANDROID_AVAILABLE = False
    activity = None

class DummyWidget(Widget):
    pass

class OverlayController:
    def __init__(self):
        self.view = None
        self.params = None
        self.wm = None
        if not ANDROID_AVAILABLE:
            return
        self._prepare()

    def _prepare(self):
        # choose overlay type by API
        try:
            OVERLAY_TYPE = LayoutParams.TYPE_APPLICATION_OVERLAY if int(Build.VERSION.SDK) >= 26 else LayoutParams.TYPE_PHONE
        except Exception:
            OVERLAY_TYPE = LayoutParams.TYPE_PHONE
        self.wm = cast('android.view.WindowManager', activity.getSystemService(Context.WINDOW_SERVICE))
        tv = TextView(activity)
        tv.setText("TradeAnalyzer\n--")
        tv.setTextSize(18)
        tv.setPadding(14, 14, 14, 14)
        tv.setBackgroundColor(Color.argb(160, 0, 0, 0))
        tv.setTextColor(Color.WHITE)
        # flags: не фокусируется, поверх всего
        FLAGS = (LayoutParams.FLAG_NOT_FOCUSABLE | LayoutParams.FLAG_LAYOUT_IN_SCREEN | LayoutParams.FLAG_NOT_TOUCH_MODAL)
        lp = LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, OVERLAY_TYPE, FLAGS, -3)
        lp.gravity = Gravity.RIGHT | Gravity.CENTER_VERTICAL
        lp.x = 10
        lp.y = 0
        self.view = tv
        self.params = lp

    def show(self):
        if not ANDROID_AVAILABLE:
            print("Android not available — overlay show skipped")
            return
        try:
            self.wm.addView(self.view, self.params)
        except Exception as e:
            print("overlay addView failed:", e)

    def update_text(self, text):
        if not ANDROID_AVAILABLE:
            # при тестовом прогоне просто печатаем
            print("Overlay text:", text)
            return
        try:
            self.view.setText(text)
        except Exception as e:
            print("overlay update failed:", e)

    def remove(self):
        if not ANDROID_AVAILABLE:
            return
        try:
            self.wm.removeView(self.view)
        except Exception:
            pass

def has_overlay_permission():
    if not ANDROID_AVAILABLE:
        return True
    if int(Build.VERSION.SDK) >= 23:
        return Settings.canDrawOverlays(activity)
    return True

def request_overlay_permission():
    if not ANDROID_AVAILABLE:
        return
    if not has_overlay_permission():
        intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
        uri = autoclass('android.net.Uri').parse("package:" + activity.getPackageName())
        intent.setData(uri)
        activity.startActivity(intent)

class OverlayApp(App):
    def build(self):
        return DummyWidget()

    def on_start(self):
        # если нет права — запросим (пользователь должен включить вручную)
        if not has_overlay_permission():
            request_overlay_permission()
            print("Requested overlay permission — grant it in settings and restart the app.")
            return
        self.controller = OverlayController()
        self.controller.show()
        # Запускаем обновление каждую секунду
        Clock.schedule_interval(self._tick, 1.0)

    def on_stop(self):
        try:
            self.controller.remove()
        except Exception:
            pass

    def _tick(self, dt):
        try:
            screenshots_dir = os.path.join(os.getcwd(), "screenshots")
            if not os.path.isdir(screenshots_dir):
                self.controller.update_text("NO FOLDER\n0%")
                return
            pics = sorted([f for f in os.listdir(screenshots_dir) if f.lower().endswith(".png")])
            if not pics:
                self.controller.update_text("NO SHOTS\n0%")
                return
            last = os.path.join(screenshots_dir, pics[-1])
            # Вызов анализатора
            if candle_analyzer and hasattr(candle_analyzer, "predict_from_image"):
                try:
                    res = candle_analyzer.predict_from_image(last)
                except Exception as e:
                    # отладочный вывод
                    self.controller.update_text("ERR\n" + str(e)[:40])
                    print("Analyzer error:", traceback.format_exc())
                    return
                signal = res.get("signal", "NEUTRAL")
                conf = res.get("confidence", res.get("confidence", 0))
                self.controller.update_text(f"{signal}\n{conf}%")
            else:
                self.controller.update_text("Analyzer\nmissing")
        except Exception as e:
            print("Tick exception:", e)
            if hasattr(self, "controller"):
                self.controller.update_text("EXC\n" + str(e)[:30])

if __name__ == "__main__":
    OverlayApp().run()
